import 'package:flutter/material.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Filmes v3',
      theme: ThemeData.dark(),
      home: MoviePage(),
    );
  }
}

class MoviePage extends StatelessWidget {
  final List<String> filmes = [
    "Breaking Bad", "Stranger Things", "Dark", "The Boys", "Round 6"
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Filmes'),
      ),
      body: ListView.builder(
        itemCount: filmes.length,
        itemBuilder: (context, index) {
          return ListTile(
            title: Text(filmes[index]),
          );
        },
      ),
    );
  }
}
